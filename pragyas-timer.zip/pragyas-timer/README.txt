Pragya's Timer - 25 / 10 repeating timer
Tap = start/pause. Long-press (1 sec) = reset.
Build APK: upload this folder to a GitHub repo -> Actions tab -> "Build APK" -> download Pragyas-Timer-APK.
